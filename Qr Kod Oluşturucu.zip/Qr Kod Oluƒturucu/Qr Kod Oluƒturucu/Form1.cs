﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MessagingToolkit.QRCode.Codec;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

namespace Qr_Kod_Oluşturucu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string[] isimlerim =
        {
            "https://www.bahadirduzcan.com.tr/"
        };
        
        private void qr_kod()
        {
            for (int i=0; i<isimlerim.Length; i++)
            {
                string kod = isimlerim[i];

                QRCodeEncoder encoder = new QRCodeEncoder();
                Bitmap qrcode = encoder.Encode(kod);
                pictureBox1.Image = qrcode as Image;
                Bitmap bmp = new Bitmap(qrcode as Image);
                Graphics g = Graphics.FromImage(bmp);
                //Image img = Properties.Resources.logo;
                Image img = Properties.Resources.loogom;
                g.DrawImage(img, 76, 76, 32, 32);
                pictureBox1.Image = bmp;
                //bmp.Save(Application.StartupPath + @"/bilisim/" + isimlerim[i].Replace('\n',' ') + ".jpg");
                bmp.Save(Application.StartupPath + @"/bilisim/bahadir.jpg");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.DesktopLocation = new Point(0, 0);
            qr_kod();
        }
    }
}
